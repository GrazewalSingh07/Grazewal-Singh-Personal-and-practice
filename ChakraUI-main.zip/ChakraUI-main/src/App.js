
import './App.css';
import Layout1 from './components/Layout1';
import Layout2 from './components/Layout2';
import Layout3 from './components/Layout3';

function App() {
  return (
    <div className="App">
      <Layout1/>
      <hr />
      <Layout2/>
      <hr />
      <Layout3/>
    </div>
  );
}

export default App;
