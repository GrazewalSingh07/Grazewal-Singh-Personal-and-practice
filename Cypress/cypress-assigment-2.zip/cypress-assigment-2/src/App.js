 
import './App.css';
import { List } from './component/List';

function App() {
  return (
    <div className="App">
      <List/>
       </div>
  );
}

export default App;
