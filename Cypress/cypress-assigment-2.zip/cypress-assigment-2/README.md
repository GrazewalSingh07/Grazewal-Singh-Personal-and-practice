 It has test case of assigment 2 ,3 and 4 as well in the same file Todo.cy.js
 
