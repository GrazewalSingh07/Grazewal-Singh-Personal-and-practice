 
import './App.css';
import { Counter } from './component/Counter';
import { Form } from './component/Form';

function App() {
  return (
    <div className="App">
      <Counter/>
      <Form/>
    </div>
  );
}

export default App;
