 


export const Home=()=>{
    return <div>
       
        <h2>WELCOME TO ELECTRONICS STORE</h2>
    </div>
}